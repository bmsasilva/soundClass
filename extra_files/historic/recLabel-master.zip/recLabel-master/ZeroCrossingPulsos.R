
blimit <- 30*1000 / (441000 / 2)
bt <- butter(10, blimit, type="high") 
somBt <- as.integer(filter(bt, som$V1))



z <- spectro(somBt,f = 441000, 
             wl = 512, ovlp = 75, osc = FALSE)

indexMax <- 0
for (i in 1:length(z$time)) {
  indexMax[i] = which.max(z$amp[,i])
}

freqMax <- 0
for (i in 1:length(z$time)) {
  freqMax[i] = z$freq[indexMax[i]]
}

intMax <- 0
for (i in 1:length(z$time)) {
  intMax[i] = z$amp[indexMax[i],i]
}

windows()
par(mar = c(5,5,2,5))
plot(z$time, freqMax)
par(new = T)
plot(z$time,intMax, type ="l",col = "red", axes = F, xlab = NA, ylab = NA)
axis(side = 4)
mtext(side = 4, line = 3, "intMax")
