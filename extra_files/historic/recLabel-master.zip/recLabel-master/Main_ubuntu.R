# Load Variables ----------------------------------------------------------
y <- list(
  SS = FALSE, #Spectral Mean subtraction (TRUE or FALSE)
  fqrcut = "manual", #High-pass Frequency for Butter filter automatic or chosen (manual or auto)
  cutoffauto = 0.5, #If fqrcut=auto, Butter High-pass Frequency in % of FMAXE frequency (integer 0 to 1)
  cutoffman = 70, #If fqrcut=manual, Butter High-pass Frequency in kHz (integer)
  cutoffman2 = 125, #If fqrcut=manual, Butter Low-pass Frequency in kHz (integer)
  butt = TRUE, #Apply Butter filter (TRUE or FALSE)
  bth = 8, #Butter filter order (2, 4, 6, 8, 10)
  savecalls = "No", #Save analysed calls to workfolder as .png files (Yes or No)
  outtable = "Classic", #Variables in result table (Full or Classic)
  callsauto = "manual", #Call selection (auto or manual) 
  tx = 10, #Time-expanded (integer, value 1 if not time-expanded)
  ffts = 1024, #FFT size for spectrogram display for call selection
  janela = "Hanning", #Window type for spectrogram display for call selection (Hanning or Hamming)
  overlap = 50, #Overlap for spectrogram display for call selection (1 to 90)
  thresh = -60 #Threshold for spectrogram display for call selection
)
attach(y)


# Load packages -----------------------------------------------------------
library(zoo)
library(signal)
library(tuneR)
library(seewave)
require(tcltk)


# Functions ---------------------------------------------------------------

main<- function() { 
  dev.off(2); dev.off(3); dev.off(4) 
  
  fileName <- list.files(".", ".wav")
  for (i in 1:length(fileName)) {
    #tryCatch({
    morc <- grav(tx,fileName[i], SS, butt, fqrcut, cutoffauto,cutoffman,cutoffman2)
    
    print(tx)
    print(morc$fs)
    ficheiro <- morc$ficheiro
    # print("morc OK")
    puls <- pulsos(morc$som,morc$somBt, ficheiro,  morc$fs, tx=tx)
    
    
    dev.off(2)
    
    # }, error=function (e) {
    #    dev.off(2)
    #   print("error")}
    #)    
  }
}

teager<-function(x) {
  t <- abs(x[2:(length(x)-1)])^2 - diff(x[1:(length(x)-1)])*diff(x[2:length(x)])
  sinal<-NaN
  sinal[x<0]<--1
  sinal[x>=0]<-1
  sinal<-sinal[2:(length(sinal)-1)]
  t<-t*sinal
}

is.wholenumber <- function(x, tol = .Machine$double.eps^0.5){  
  abs(x - round(x)) < tol
}

spec.bs.colors<-function (n) {
  a<-rev(c("#00001F","#00002F","#00003F","#00004F","#00005F",
           "#00006F","#00007F","#00008F","#00009F","#0000AF",
           "#0000BF","#0000CF","#0000DF","#0000EF","#0000FF",
           "#0F00F0","#1F00E0","#2F00D0","#3F00C0","#4F00B0",
           "#5F00A0","#6F0090","#7F0080","#8F0070","#9F0060",
           "#AF0050","#BF0040","#CF0030","#DF0020","#EF0010",
           "#FF0000","#FF0F00","#FF1F00","#FF2F00","#FF3F00",
           "#FF4F00","#FF5F00","#FF6F00","#FF7F00","#FF8F00",
           "#FF9F00","#FFAF00","#FFBF00","#FFCF00","#FFDF00",
           "#FFEF00","#FFFF00","#FFFF0F","#FFFF1F","#FFFF2F",
           "#FFFF3F","#FFFF4F","#FFFF5F","#FFFF6F","#FFFF7F",
           "#FFFF8F","#FFFF9F","#FFFFAF","#FFFFBF","#FFFFCF"))
  c(palette(a))
}

grav<-function(tx,fileName, SS=FALSE, butt=TRUE, fqrcut="auto", cutoffauto,cutoffman,cutoffman2) { 
  ficheiro <- unlist(strsplit(fileName, "\\\\")) # separa pela barra Em Ubuntu e diferente, tenho de ver como se faz
  ficheiro <- unlist(strsplit(ficheiro, "\\.")) # separa pelo ponto 
  ficheiro <- ficheiro[length(ficheiro)-1] # selecciona o nome do ficheiro
  dados <- readWave(fileName)
  fs <- dados@samp.rate
  if (dados@stereo)  { # se dados@stereo=TRUE converte para mono
    if (sum(abs(dados@left))>=sum(abs(dados@right))) {
      som <- dados@left
    }  else {        
      som <- dados@right
    }
  }  else { # se dados@stereo=FALSE
    som <- dados@left 
  }
  if (butt) { # aplicar filtro butterworth
    if(fqrcut=="auto") {
      somnpow2 <- zp(som,npow2(length(som)))
      fmaxe <- floor(F.MAXE(somnpow2,fs,tx))*1000 ##Valor em Hz
      blimit <- fmaxe * cutoffauto / (fs * tx / 2)
      bt <- butter(10, blimit, type="high")
      somBt <- as.integer(filter(bt, som))
    }  else {
      blimit <- cutoffman*1000 / (fs * tx / 2)
      blimit2 <- cutoffman2*1000 / (fs * tx / 2)
      bt <- butter(10, blimit, type="high")
      bt2 <- butter(10, blimit2, type="low") 
      somBt <- as.integer(filter(bt, som))
      somBt <- as.integer(filter(bt2, somBt))
    }
  } # final do if "butt"
  somf<-som
  if (SS) 
    somf<-SMS(somf,fs,tx)
  somf<-rollmean(abs(teager(somf)),tx)
  list(som=som, somBt=somBt,ficheiro=ficheiro,fs=fs)
} #  final da fun??o

pulsos<-function(som,somBt, ficheiro,  fs=fs, tx=tx, tintervalo=40) {
  options(locatorBell=FALSE)
  ## Plota o espectrograma para o utilizador selecionar os pulsos
  X11(width=20)
  spectro(somBt,main=ficheiro,grid=F,scale=F,heights=c(1,1),dBref=2, #tirando este valor o dBref ? o mais intenso da grav
          collevels = seq(thresh,0, 1), flim=c(0,120), f = fs * tx, 
          wl = ffts, ovlp = overlap, osc = FALSE,  palette = spec.bs.colors) 
  
  pos <- locator(n = 512)
  pos <- as.integer(pos$x * (fs * tx))
  np <- length(pos)/2 
  while(is.wholenumber(np)==FALSE) { # Se forem seleccionados pontos em n?mero impar repete a escolha
    ReturnVal <- tkmessageBox(title="Erro",message="E necessario escolher os pulsos novamente",icon="info",type="ok")
    pos<-locator(n = 512)
    pos<-round(pos$x * (fs * tx),0)# Por este vector em matriz
    np<-length(pos)/2 
  }
  ## Obtém o local de fmaxe de cada pulso seleccionado anteriormente
  j<-1
  maxpos<-NULL
  for (i in 1:np) {
    maxpos[i]<-which.max(somBt[pos[j]:pos[j+1]])+pos[j]
    #i<-1+1
    j<-j+2
  }
  
  
  #Grava em csv matriz com o local de cada pulso na gravacao
  write.table(maxpos,file=paste(ficheiro,"_posicaoPulsos",".csv"),
              append=TRUE, row.names=FALSE, col.names=FALSE, sep=",")
  
  
  #Grava em wav e csv o intervalo de cada pulso e o png do respectivo espectrograma 
  for (i in 1:length(maxpos)){
    
    #wav  
    callToSave <- som[(maxpos[i]-fs*tx*tintervalo/1000):(maxpos[i]+fs*tx*tintervalo/1000)]
    savewav(callToSave,fs,file=paste(ficheiro,"_",i,".wav"))
    
    #png
    png(paste(ficheiro,"_",i,"_","512",".png"))
    spectro(dBref=2,callToSave, scale=T,heights=c(1,1),
            collevels = seq(-60,0, 1), flim=c(2,120), f = fs*tx, wl = 512, ovlp = 85, 
            osc = TRUE,  palette=spec.bs.colors)
    dev.off()
    
    #csv
    callToSave <- matrix(callToSave,ncol=1)
    write.table(callToSave,file=paste(ficheiro,"_",i,".csv"),
                append=TRUE, row.names=FALSE, col.names=FALSE, sep=",")
    
    
    
  }
  
  list(np=np,pos=pos,maxpos=maxpos)
} 


main()

